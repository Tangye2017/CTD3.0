"use strict";

const DATA_ROOT = "./data/";
const MENU      = {};
const MENUITEMS = Object.assign(require(DATA_ROOT + "foodMenuData.json"), MENU);

module.exports = {
	  metadata: () => ({
		name: 'getFoodMenu',
		properties: {
		  menuOption: { required: true, type: 'string' },
		  menuSlotVar: { required: true, type: 'string' }
		},
		supportedActions: ["Success", "Failure"]
	  }),
    invoke: (conversation, done) => {
      // Generic CC variables ==================================================
      var userId      = conversation.request().message.channelConversation.userId;
      var firstName   = conversation.variable("profile.firstName");
      var errMsg      = "I am sorry " + firstName + ", but I have a pain in all my Diodes down the left side!";

      // CC specific Variables =================================================
      var menuOption  = conversation.properties().menuOption;
      var menuSlotVar = conversation.properties().menuSlotVar;
      //var menuStyle   = conversation.properties().menuStyle;
      var channelType = conversation.channelType();
      var firstName   = conversation.variable("profile.firstName");
      var chosenFood  = "";
      var ccPhase     = conversation.variable("foodMenuPhase");   // 1st or 2nd call to CC
      var baseURL     = "https://jpac2-gse00009991.sites.us2.oraclecloud.com/CafeSupremo/_themesdelivery/CafeSupremoTheme/assets/img/bot/";
      var menuItems   = [];
      var fbmCarousel = "";

      // =======================================================================
      //   Check if this is first call to component and either render UI
      //   or respond to selection of Menu Item
      // =======================================================================

      if ( (ccPhase === undefined) || (ccPhase == null) || (ccPhase === '') || (ccPhase === '1') ) {

        // First Call to CC so generate UI =====================================
        console.log("getFoodMenu", "<<DEBUG>> getFoodMenu Phase 1 ");

        // New CRC based Carousel
        // Get data and fill in Menu Items into the Carousel
        var messageModel = conversation.MessageModel();

        for (var menuItemId in MENUITEMS) {
          let menuItem = MENUITEMS[menuItemId];
          console.log("getFoodMenu", "<<DEBUG>> getFoodMenu menuItem = " + menuItem.itemName);

          if ( (menuItem.menuOption === menuOption) || ( menuOption == 'All Food') ) {

            let itemCardName     = menuItem.itemName;
            let itemCardSubtitle = menuItem.description;
            let itemCardImageUrl = baseURL + menuItem.imageName;
            let itemCardAction   = messageModel.postbackActionObject("Select", null,{"itemOrdered": menuItem.itemName, "itemImage": itemCardImageUrl} );
            let itemCard         = messageModel.cardObject(itemCardName, itemCardSubtitle, itemCardImageUrl, null, [itemCardAction]);
            menuItems.push(itemCard);
          }
        }
        var itemCardsDeck = messageModel.cardConversationMessage('horizontal', menuItems);
        conversation.reply({text: "This is what we have in our " + menuOption + " menu\nHopefully there is something you will Like!"})
        conversation.reply(itemCardsDeck);
        conversation.variable("foodMenuPhase",'2');
        done();
        // =====================================================================
      }
      else
      {
        // Second Call to CC so User is interacting with the UI ================
        if ((conversation.text() === undefined) || (conversation.text() == null)) {
          console.log("getFoodMenu", "<<DEBUG>> getFoodMenu Phase 2 : Button pressed with payload= " + conversation.postback().itemOrdered);
          chosenFood = conversation.postback().itemOrdered;
        }
        else
        {
          console.log("getFoodMenu", "<<DEBUG>> getFoodMenu Phase 2 : Text entered with payload= " + conversation.text());
          chosenFood = conversation.text();
        }
        console.log("getFoodMenu", "<<DEBUG>> Phase 2 Loading Slot Variable");
        
        conversation.variable(menuSlotVar,chosenFood);
        conversation.variable("foodMenuPhase",'1');
        conversation.keepTurn(true);
        conversation.transition("Success");
        done();
        // =====================================================================
      }
    }
  };
