module.exports = {
  components: [
    './components'
  ]
};